                    <div class="col-xs-6">
                    	<a href="#"><img class="img-responsive inlineblock" alt="Live Support" src="<?=base_url()."media/";?>images/live-support.jpg"></a>
                    </div>
                    <div class="col-xs-6">
                    	<a href="#"><img class="img-responsive inlineblock" alt="Skype Support" src="<?=base_url()."media/";?>images/skype-support.jpg"></a>
<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
<div id="SkypeButton_Call_sfx.partnership_1">
 <script type="text/javascript">
 Skype.ui({
 "name": "dropdown",
 "element": "SkypeButton_Call_sfx.partnership_1",
 "participants": ["sfx.partnership"]
 });
 </script>
</div>
                    </div>