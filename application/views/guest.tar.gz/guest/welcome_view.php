<?php 
 
?>
<div class="container">
    	<div class="row">
        	<div class="main col-md-12">
            	<h3 class="orange nomargin"><strong>Register to the Secure Area of SalmaForex</strong></h3>
                <p>Welcome and Join With Us</p>
                <div class="vspace-30"></div>
            </div>
    		<div class="main-left col-md-7">
            	<!--form class="form-horizontal">
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
                    <div class="col-sm-10">
                      <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-default">Register</button>
                    </div>
                  </div>
                </form-->				
<?php 
			$load_view=$baseFolder.'form_view';
			$this->load->view($load_view); 
?>
			<div class="vspace-30"></div>
            </div>
            <div class="col-md-1 col-sm-2"></div>
            <div class="col-md-4 col-sm-10" style='display:none'>
            	<div class="row">
<?php 
			$load_view=$baseFolder.'inc/support_view';
			$this->load->view($load_view); 
?>
                </div>
            </div>
    	</div>
    </div>
