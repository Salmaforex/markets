<?php 
if (   function_exists('logFile')){ logFile('view/member/api','partner_revenue_view.php','view'); };
redirect('member');
?>
on progress