<?php 
//deposit_view.php
if (  function_exists('logFile')){ logFile('view/depan/inc','done.php','data'); };

defined('BASEPATH') OR exit('No direct script access allowed');
 
?>
<div class="main col-md-8">
			<div style='margin-top:30px;'>
				<h3>Your Order Was Sent Successfully. Please Check Your Email. Thanks.</h3>
			</div>
</div>