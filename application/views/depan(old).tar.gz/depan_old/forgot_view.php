<?php
defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class='container'>
    <div style='margin-top:30px;'>
        <form novalidate="novalidate" name="frm" id0="frm" id="frmLiveAccount" method="POST"  class="form-horizontal" role="form"> 
			<div class="frame-form-basic">
			<h2>Forgot Your Password</h2>
      
          <div class="panel-body">
            <div class="form-group">

              <label for="myEmail1">
                Your Email
              </label>
              <input class="form-control" id="myUser" type="text" name="email" />
            </div> 
             
            <button type="button" class="btn btn-default submitLogin" onclick="forgotpass()">
              Recover  
            </button>
          </div>
          <div class='clear'></div> 
        </div>
      </form>
    </div>
     
</div>
<script>

</script>