                    <div class="col-xs-6 div_support">
                    	<a href="#"><img class="img-responsive inlineblock" alt="Live Support" src="<?=base_url()."media/";?>images/live-support.jpg"></a>
                    </div>
                    <div class="col-xs-6 div_support">
                    	<a href="#"><img class="img-responsive inlineblock" alt="Skype Support" src="<?=base_url()."media/";?>images/skype-support.jpg"></a>

                    </div>