<div class="header">
	<div class="container">
    	<div class="logo">
		<img alt="Salma Market Logo" src="<?=base_url()."media/";?>images/top-logo001.jpg" />
		</div>
    </div>
</div>