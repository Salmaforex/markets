-- phpMyAdmin SQL Dump
-- version 4.4.15.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 04, 2017 at 08:23 AM
-- Server version: 5.6.28
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mujur_forex`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_id`
--

CREATE TABLE IF NOT EXISTS `account_id` (
  `id` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `acc_detail2`
--

CREATE TABLE IF NOT EXISTS `acc_detail2` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `detail` text CHARACTER SET utf32 COLLATE utf32_bin COMMENT 'akun detail',
  `email` varchar(100) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `activation_id`
--

CREATE TABLE IF NOT EXISTS `activation_id` (
  `id` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `api_account_id`
--

CREATE TABLE IF NOT EXISTS `api_account_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `api_datatable_id`
--

CREATE TABLE IF NOT EXISTS `api_datatable_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `api_forex_id`
--

CREATE TABLE IF NOT EXISTS `api_forex_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `api_id`
--

CREATE TABLE IF NOT EXISTS `api_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `api_users_id`
--

CREATE TABLE IF NOT EXISTS `api_users_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE IF NOT EXISTS `cache` (
  `num` int(11) NOT NULL,
  `id` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_session`
--

CREATE TABLE IF NOT EXISTS `ci_session` (
  `num` bigint(20) NOT NULL,
  `data` longtext NOT NULL,
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(46) NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `timestamp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE IF NOT EXISTS `currency` (
  `id` bigint(20) NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` datetime DEFAULT '2017-07-01 00:00:00',
  `deleted` tinyint(4) DEFAULT NULL,
  `code` varchar(10) DEFAULT 'IDR',
  `name` varchar(255) DEFAULT 'Rupiah',
  `symbol` varchar(255) DEFAULT 'Rp',
  `detail` longtext,
  `approved` tinyint(4) DEFAULT NULL,
  `last_update` longtext,
  `log_last_update` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `id`
--

CREATE TABLE IF NOT EXISTS `id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `log_id`
--

CREATE TABLE IF NOT EXISTS `log_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mail_id`
--

CREATE TABLE IF NOT EXISTS `mail_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_account`
--

CREATE TABLE IF NOT EXISTS `mujur_account` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` date NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `investorpassword` varchar(100) NOT NULL,
  `masterpassword` varchar(100) NOT NULL,
  `reg_id` bigint(20) NOT NULL,
  `accountid` bigint(20) NOT NULL DEFAULT '1',
  `status` tinyint(4) DEFAULT NULL,
  `agent` varchar(31) DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'MEMBER'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_account160425`
--

CREATE TABLE IF NOT EXISTS `mujur_account160425` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` date NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `investorpassword` varchar(100) NOT NULL,
  `masterpassword` varchar(100) NOT NULL,
  `reg_id` bigint(20) NOT NULL,
  `accountid` bigint(20) NOT NULL DEFAULT '1',
  `type` varchar(20) NOT NULL DEFAULT 'MEMBER'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_account160704`
--

CREATE TABLE IF NOT EXISTS `mujur_account160704` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` date NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `investorpassword` varchar(100) NOT NULL,
  `masterpassword` varchar(100) NOT NULL,
  `reg_id` bigint(20) NOT NULL,
  `accountid` bigint(20) NOT NULL DEFAULT '1',
  `status` tinyint(4) DEFAULT NULL,
  `agent` varchar(31) DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'MEMBER'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_accountbalance`
--

CREATE TABLE IF NOT EXISTS `mujur_accountbalance` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `detail` text NOT NULL,
  `balance` decimal(19,7) NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expired` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_accountdetail`
--

CREATE TABLE IF NOT EXISTS `mujur_accountdetail` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `detail` longtext NOT NULL,
  `document` tinyint(4) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_accountdetail_9`
--

CREATE TABLE IF NOT EXISTS `mujur_accountdetail_9` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `detail` text CHARACTER SET utf32 COLLATE utf32_bin COMMENT 'akun detail',
  `document` tinyint(4) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_accountdocument`
--

CREATE TABLE IF NOT EXISTS `mujur_accountdocument` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `upload` longtext NOT NULL,
  `filetype` varchar(100) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_accountrecover`
--

CREATE TABLE IF NOT EXISTS `mujur_accountrecover` (
  `id` bigint(20) NOT NULL,
  `params` longtext NOT NULL,
  `detail` longtext NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expired` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_account_8`
--

CREATE TABLE IF NOT EXISTS `mujur_account_8` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` date NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `investorpassword` varchar(100) NOT NULL,
  `masterpassword` varchar(100) NOT NULL,
  `reg_id` bigint(20) NOT NULL,
  `accountid` bigint(20) NOT NULL DEFAULT '1',
  `status` tinyint(4) DEFAULT NULL,
  `agent` varchar(31) DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'MEMBER'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_account_9`
--

CREATE TABLE IF NOT EXISTS `mujur_account_9` (
  `id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` date NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `investorpassword` varchar(100) NOT NULL,
  `masterpassword` varchar(100) NOT NULL,
  `reg_id` bigint(20) NOT NULL,
  `accountid` bigint(20) NOT NULL DEFAULT '1',
  `status` tinyint(4) DEFAULT NULL,
  `agent` varchar(31) DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'MEMBER'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_activation`
--

CREATE TABLE IF NOT EXISTS `mujur_activation` (
  `id` bigint(20) NOT NULL,
  `code` text COMMENT 'kode aktivasi',
  `userid` bigint(20) NOT NULL,
  `expired` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_admin`
--

CREATE TABLE IF NOT EXISTS `mujur_admin` (
  `adm_id` int(11) NOT NULL,
  `adm_username` varchar(200) NOT NULL,
  `adm_type` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_api`
--

CREATE TABLE IF NOT EXISTS `mujur_api` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_api160425`
--

CREATE TABLE IF NOT EXISTS `mujur_api160425` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_country`
--

CREATE TABLE IF NOT EXISTS `mujur_country` (
  `country_id` int(11) NOT NULL,
  `country_created` date NOT NULL,
  `country_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_country0`
--

CREATE TABLE IF NOT EXISTS `mujur_country0` (
  `country_id` int(11) NOT NULL,
  `country_code` varchar(50) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  `country_created` datetime NOT NULL,
  `country_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_email`
--

CREATE TABLE IF NOT EXISTS `mujur_email` (
  `id` bigint(20) NOT NULL,
  `to` varchar(200) NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `subject` text NOT NULL,
  `messages` text,
  `headers` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_flowlog`
--

CREATE TABLE IF NOT EXISTS `mujur_flowlog` (
  `id` bigint(20) NOT NULL,
  `types` varchar(200) CHARACTER SET utf32 COLLATE utf32_bin DEFAULT NULL,
  `param` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT '0',
  `email` varchar(255) DEFAULT '',
  `accountid` varchar(255) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_logs`
--

CREATE TABLE IF NOT EXISTS `mujur_logs` (
  `id` bigint(20) NOT NULL,
  `controller` varchar(200) NOT NULL,
  `function` text NOT NULL,
  `param` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_password`
--

CREATE TABLE IF NOT EXISTS `mujur_password` (
  `id` bigint(20) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_price`
--

CREATE TABLE IF NOT EXISTS `mujur_price` (
  `id` bigint(20) NOT NULL,
  `types` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(4) DEFAULT NULL,
  `currency` varchar(255) DEFAULT 'IDR',
  `detail` longtext,
  `approved` tinyint(4) DEFAULT NULL,
  `last_update` longtext,
  `log_last_update` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_register`
--

CREATE TABLE IF NOT EXISTS `mujur_register` (
  `reg_id` bigint(20) NOT NULL,
  `reg_username` varchar(50) NOT NULL,
  `reg_password` varchar(50) NOT NULL,
  `reg_investorpassword` varchar(100) NOT NULL,
  `reg_email` varchar(200) NOT NULL,
  `reg_detail` text NOT NULL,
  `reg_created` datetime NOT NULL,
  `reg_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reg_status` int(11) NOT NULL,
  `reg_agent` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_register0`
--

CREATE TABLE IF NOT EXISTS `mujur_register0` (
  `reg_id` bigint(20) NOT NULL,
  `reg_username` varchar(50) NOT NULL,
  `reg_password` varchar(50) NOT NULL,
  `reg_detail` text NOT NULL,
  `reg_created` datetime NOT NULL,
  `reg_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reg_status` int(11) NOT NULL,
  `reg_agent` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_register1702`
--

CREATE TABLE IF NOT EXISTS `mujur_register1702` (
  `reg_id` bigint(20) NOT NULL,
  `reg_username` varchar(50) NOT NULL,
  `reg_password` varchar(50) NOT NULL,
  `reg_investorpassword` varchar(100) NOT NULL,
  `reg_email` varchar(200) NOT NULL,
  `reg_detail` text NOT NULL,
  `reg_created` datetime NOT NULL,
  `reg_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reg_status` int(11) NOT NULL,
  `reg_agent` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_register1705`
--

CREATE TABLE IF NOT EXISTS `mujur_register1705` (
  `reg_id` bigint(20) NOT NULL,
  `reg_username` varchar(50) NOT NULL,
  `reg_password` varchar(50) NOT NULL,
  `reg_investorpassword` varchar(100) NOT NULL,
  `reg_email` varchar(200) NOT NULL,
  `reg_detail` text NOT NULL,
  `reg_created` datetime NOT NULL,
  `reg_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reg_status` int(11) NOT NULL,
  `reg_agent` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_users`
--

CREATE TABLE IF NOT EXISTS `mujur_users` (
  `u_id` bigint(20) NOT NULL COMMENT 'counter',
  `u_email` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT 'fix type',
  `u_password` varchar(100) NOT NULL,
  `u_type` mediumint(9) NOT NULL,
  `u_status` tinyint(4) NOT NULL,
  `u_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `u_mastercode` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_usersdetail`
--

CREATE TABLE IF NOT EXISTS `mujur_usersdetail` (
  `id` bigint(20) NOT NULL,
  `ud_email` varchar(255) NOT NULL,
  `ud_detail` text CHARACTER SET utf32 COLLATE utf32_bin COMMENT 'akun detail',
  `ud_document` tinyint(4) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_usersdocument`
--

CREATE TABLE IF NOT EXISTS `mujur_usersdocument` (
  `id` bigint(20) NOT NULL,
  `udoc_email` varchar(255) DEFAULT NULL,
  `udoc_status` tinyint(4) DEFAULT NULL,
  `udoc_upload` text NOT NULL,
  `filetype` varchar(100) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `profile_type` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_usersdocument_1`
--

CREATE TABLE IF NOT EXISTS `mujur_usersdocument_1` (
  `id` bigint(20) NOT NULL,
  `udoc_email` varchar(255) DEFAULT NULL,
  `udoc_status` tinyint(4) DEFAULT NULL,
  `udoc_upload` text NOT NULL,
  `filetype` varchar(100) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `profile_pic` varchar(255) DEFAULT '',
  `profile_type` varchar(25) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_userstype`
--

CREATE TABLE IF NOT EXISTS `mujur_userstype` (
  `ut_id` bigint(20) NOT NULL,
  `ut_name` varchar(40) NOT NULL,
  `ut_detail` text NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mujur_users_erase`
--

CREATE TABLE IF NOT EXISTS `mujur_users_erase` (
  `u_id` int(11) NOT NULL,
  `u_email` varchar(90) NOT NULL,
  `u_password` varchar(50) NOT NULL,
  `u_type` int(11) NOT NULL,
  `u_status` tinyint(4) NOT NULL,
  `u_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `u_mastercode` varchar(50) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `palsu`
--

CREATE TABLE IF NOT EXISTS `palsu` (
  `u_id` int(11) NOT NULL,
  `u_email` varchar(90) NOT NULL,
  `u_password` varchar(50) NOT NULL,
  `u_type` int(11) NOT NULL,
  `u_status` tinyint(4) NOT NULL,
  `u_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `random_id`
--

CREATE TABLE IF NOT EXISTS `random_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `recover_id`
--

CREATE TABLE IF NOT EXISTS `recover_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL,
  `texts` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rest_account`
--

CREATE TABLE IF NOT EXISTS `rest_account` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rest_api`
--

CREATE TABLE IF NOT EXISTS `rest_api` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rest_datatable`
--

CREATE TABLE IF NOT EXISTS `rest_datatable` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rest_forex`
--

CREATE TABLE IF NOT EXISTS `rest_forex` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rest_temp`
--

CREATE TABLE IF NOT EXISTS `rest_temp` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rest_user`
--

CREATE TABLE IF NOT EXISTS `rest_user` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rest_users`
--

CREATE TABLE IF NOT EXISTS `rest_users` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `site_ping`
--

CREATE TABLE IF NOT EXISTS `site_ping` (
  `id` bigint(20) NOT NULL,
  `url` varchar(1000) DEFAULT NULL,
  `detail` text NOT NULL,
  `error` text NOT NULL,
  `status` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `token_id`
--

CREATE TABLE IF NOT EXISTS `token_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users_id`
--

CREATE TABLE IF NOT EXISTS `users_id` (
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_account_simple`
--
CREATE TABLE IF NOT EXISTS `v_account_simple` (
`username` varchar(100)
,`email` varchar(255)
,`reg_id` bigint(20)
,`accountid` bigint(20)
,`detail` longtext
,`created` date
,`investorpassword` varchar(100)
,`masterpassword` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_api_register_all`
--
CREATE TABLE IF NOT EXISTS `v_api_register_all` (
`tanggal` date
,`total` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_api_register_failed`
--
CREATE TABLE IF NOT EXISTS `v_api_register_failed` (
`tanggal` date
,`id` bigint(20)
,`url` text
,`response` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_api_register_success`
--
CREATE TABLE IF NOT EXISTS `v_api_register_success` (
`tanggal` date
,`url` text
,`response` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_api_total_register_failed`
--
CREATE TABLE IF NOT EXISTS `v_api_total_register_failed` (
`tanggal` date
,`total` bigint(21)
,`response` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_api_total_register_success`
--
CREATE TABLE IF NOT EXISTS `v_api_total_register_success` (
`tanggal` date
,`total` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_register_failed`
--
CREATE TABLE IF NOT EXISTS `v_register_failed` (
`id` bigint(20)
,`created` datetime
,`email` varchar(200)
,`detail` text
,`status` int(11)
,`agent` varchar(30)
,`reg_password` varchar(50)
,`reg_investorpassword` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_register_ok`
--
CREATE TABLE IF NOT EXISTS `v_register_ok` (
`id` bigint(20)
,`created` datetime
,`email` varchar(200)
,`detail` text
,`status` int(11)
,`agent` varchar(30)
,`reg_password` varchar(50)
,`reg_investorpassword` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_register_status`
--
CREATE TABLE IF NOT EXISTS `v_register_status` (
`tanggal register` date
,`total` bigint(21)
,`rawStatus` varchar(7)
,`status` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `zbatch_email`
--

CREATE TABLE IF NOT EXISTS `zbatch_email` (
  `id` bigint(20) NOT NULL,
  `to` varchar(200) NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `subject` text NOT NULL,
  `messages` text,
  `headers` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1462744928`
--

CREATE TABLE IF NOT EXISTS `zlog_1462744928` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463263326`
--

CREATE TABLE IF NOT EXISTS `zlog_1463263326` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463349726`
--

CREATE TABLE IF NOT EXISTS `zlog_1463349726` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463436127`
--

CREATE TABLE IF NOT EXISTS `zlog_1463436127` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463522525`
--

CREATE TABLE IF NOT EXISTS `zlog_1463522525` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463608932`
--

CREATE TABLE IF NOT EXISTS `zlog_1463608932` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463695328`
--

CREATE TABLE IF NOT EXISTS `zlog_1463695328` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463781728`
--

CREATE TABLE IF NOT EXISTS `zlog_1463781728` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463868127`
--

CREATE TABLE IF NOT EXISTS `zlog_1463868127` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1463954528`
--

CREATE TABLE IF NOT EXISTS `zlog_1463954528` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464040930`
--

CREATE TABLE IF NOT EXISTS `zlog_1464040930` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464127328`
--

CREATE TABLE IF NOT EXISTS `zlog_1464127328` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464213729`
--

CREATE TABLE IF NOT EXISTS `zlog_1464213729` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464300128`
--

CREATE TABLE IF NOT EXISTS `zlog_1464300128` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464386527`
--

CREATE TABLE IF NOT EXISTS `zlog_1464386527` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464472933`
--

CREATE TABLE IF NOT EXISTS `zlog_1464472933` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464559327`
--

CREATE TABLE IF NOT EXISTS `zlog_1464559327` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464645744`
--

CREATE TABLE IF NOT EXISTS `zlog_1464645744` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464732129`
--

CREATE TABLE IF NOT EXISTS `zlog_1464732129` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464818530`
--

CREATE TABLE IF NOT EXISTS `zlog_1464818530` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464904930`
--

CREATE TABLE IF NOT EXISTS `zlog_1464904930` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1464991329`
--

CREATE TABLE IF NOT EXISTS `zlog_1464991329` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465077728`
--

CREATE TABLE IF NOT EXISTS `zlog_1465077728` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465164131`
--

CREATE TABLE IF NOT EXISTS `zlog_1465164131` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465250527`
--

CREATE TABLE IF NOT EXISTS `zlog_1465250527` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465336927`
--

CREATE TABLE IF NOT EXISTS `zlog_1465336927` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465423329`
--

CREATE TABLE IF NOT EXISTS `zlog_1465423329` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465509732`
--

CREATE TABLE IF NOT EXISTS `zlog_1465509732` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465596129`
--

CREATE TABLE IF NOT EXISTS `zlog_1465596129` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465682530`
--

CREATE TABLE IF NOT EXISTS `zlog_1465682530` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465768938`
--

CREATE TABLE IF NOT EXISTS `zlog_1465768938` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465855322`
--

CREATE TABLE IF NOT EXISTS `zlog_1465855322` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1465941723`
--

CREATE TABLE IF NOT EXISTS `zlog_1465941723` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1466373723`
--

CREATE TABLE IF NOT EXISTS `zlog_1466373723` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1466460122`
--

CREATE TABLE IF NOT EXISTS `zlog_1466460122` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zlog_1466546533`
--

CREATE TABLE IF NOT EXISTS `zlog_1466546533` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zrest_account`
--

CREATE TABLE IF NOT EXISTS `zrest_account` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zrest_datatable`
--

CREATE TABLE IF NOT EXISTS `zrest_datatable` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zrest_forex`
--

CREATE TABLE IF NOT EXISTS `zrest_forex` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zrest_users`
--

CREATE TABLE IF NOT EXISTS `zrest_users` (
  `id` bigint(20) NOT NULL,
  `function` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `result` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `z_api`
--

CREATE TABLE IF NOT EXISTS `z_api` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `z_api_2`
--

CREATE TABLE IF NOT EXISTS `z_api_2` (
  `id` bigint(20) NOT NULL,
  `url` text NOT NULL,
  `parameter` text NOT NULL,
  `response` text NOT NULL,
  `error` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `z_temp_api`
--

CREATE TABLE IF NOT EXISTS `z_temp_api` (
  `id` bigint(20) NOT NULL,
  `params` text NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `count_execute` int(11) NOT NULL DEFAULT '1' COMMENT 'berapa kali digunakan',
  `created` datetime DEFAULT NULL,
  `functions` varchar(100) DEFAULT NULL,
  `member_login` varchar(200) DEFAULT NULL,
  `result` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `z_temp_local`
--

CREATE TABLE IF NOT EXISTS `z_temp_local` (
  `id` bigint(20) NOT NULL,
  `params` text NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `count_execute` int(11) NOT NULL DEFAULT '1' COMMENT 'berapa kali digunakan',
  `created` datetime DEFAULT NULL,
  `api` varchar(50) DEFAULT NULL,
  `functions` varchar(100) DEFAULT NULL,
  `member_login` varchar(200) DEFAULT NULL,
  `result` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure for view `v_account_simple`
--
DROP TABLE IF EXISTS `v_account_simple`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_account_simple` AS select `a`.`username` AS `username`,`a`.`email` AS `email`,`a`.`reg_id` AS `reg_id`,`a`.`accountid` AS `accountid`,`ad`.`detail` AS `detail`,`a`.`created` AS `created`,`a`.`investorpassword` AS `investorpassword`,`a`.`masterpassword` AS `masterpassword` from (`mujur_account` `a` left join `mujur_accountdetail` `ad` on((`ad`.`username` = convert(`a`.`username` using utf8))));

-- --------------------------------------------------------

--
-- Structure for view `v_api_register_all`
--
DROP TABLE IF EXISTS `v_api_register_all`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_api_register_all` AS select cast(`mujur_api`.`created` as date) AS `tanggal`,count(`mujur_api`.`id`) AS `total` from `mujur_api` where (`mujur_api`.`url` like '%register%') group by cast(`mujur_api`.`created` as date);

-- --------------------------------------------------------

--
-- Structure for view `v_api_register_failed`
--
DROP TABLE IF EXISTS `v_api_register_failed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_api_register_failed` AS select cast(`mujur_api`.`created` as date) AS `tanggal`,`mujur_api`.`id` AS `id`,`mujur_api`.`url` AS `url`,`mujur_api`.`response` AS `response` from `mujur_api` where ((`mujur_api`.`url` like '%register%') and (not((`mujur_api`.`response` like '%masterpassword%'))));

-- --------------------------------------------------------

--
-- Structure for view `v_api_register_success`
--
DROP TABLE IF EXISTS `v_api_register_success`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_api_register_success` AS select cast(`mujur_api`.`created` as date) AS `tanggal`,`mujur_api`.`url` AS `url`,`mujur_api`.`response` AS `response` from `mujur_api` where ((`mujur_api`.`url` like '%register%') and (`mujur_api`.`response` like '%masterpassword%'));

-- --------------------------------------------------------

--
-- Structure for view `v_api_total_register_failed`
--
DROP TABLE IF EXISTS `v_api_total_register_failed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_api_total_register_failed` AS select cast(`mujur_api`.`created` as date) AS `tanggal`,count(`mujur_api`.`id`) AS `total`,`mujur_api`.`response` AS `response` from `mujur_api` where ((`mujur_api`.`url` like '%register%') and (not((`mujur_api`.`response` like '%masterpassword%')))) group by cast(`mujur_api`.`created` as date),`mujur_api`.`response`;

-- --------------------------------------------------------

--
-- Structure for view `v_api_total_register_success`
--
DROP TABLE IF EXISTS `v_api_total_register_success`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_api_total_register_success` AS select cast(`mujur_api`.`created` as date) AS `tanggal`,count(`mujur_api`.`id`) AS `total` from `mujur_api` where ((`mujur_api`.`url` like '%register%') and (`mujur_api`.`response` like '%masterpassword%')) group by cast(`mujur_api`.`created` as date);

-- --------------------------------------------------------

--
-- Structure for view `v_register_failed`
--
DROP TABLE IF EXISTS `v_register_failed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_register_failed` AS select `mujur_register`.`reg_id` AS `id`,`mujur_register`.`reg_created` AS `created`,`mujur_register`.`reg_email` AS `email`,`mujur_register`.`reg_detail` AS `detail`,`mujur_register`.`reg_status` AS `status`,`mujur_register`.`reg_agent` AS `agent`,`mujur_register`.`reg_password` AS `reg_password`,`mujur_register`.`reg_investorpassword` AS `reg_investorpassword` from `mujur_register` where (`mujur_register`.`reg_status` > 1) order by `mujur_register`.`reg_created` desc;

-- --------------------------------------------------------

--
-- Structure for view `v_register_ok`
--
DROP TABLE IF EXISTS `v_register_ok`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_register_ok` AS select `mujur_register`.`reg_id` AS `id`,`mujur_register`.`reg_created` AS `created`,`mujur_register`.`reg_email` AS `email`,`mujur_register`.`reg_detail` AS `detail`,`mujur_register`.`reg_status` AS `status`,`mujur_register`.`reg_agent` AS `agent`,`mujur_register`.`reg_password` AS `reg_password`,`mujur_register`.`reg_investorpassword` AS `reg_investorpassword` from `mujur_register` where (`mujur_register`.`reg_status` <= 1) order by `mujur_register`.`reg_created` desc;

-- --------------------------------------------------------

--
-- Structure for view `v_register_status`
--
DROP TABLE IF EXISTS `v_register_status`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u429780871_forex`@`localhost` SQL SECURITY DEFINER VIEW `v_register_status` AS select cast(`mujur_register`.`reg_created` as date) AS `tanggal register`,count(0) AS `total`,if((`mujur_register`.`reg_status` = 0),'SUCCESS','Other') AS `rawStatus`,`mujur_register`.`reg_status` AS `status` from `mujur_register` group by cast(`mujur_register`.`reg_created` as date),`mujur_register`.`reg_status`;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_id`
--
ALTER TABLE `account_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `acc_detail2`
--
ALTER TABLE `acc_detail2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activation_id`
--
ALTER TABLE `activation_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_account_id`
--
ALTER TABLE `api_account_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_datatable_id`
--
ALTER TABLE `api_datatable_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_forex_id`
--
ALTER TABLE `api_forex_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_id`
--
ALTER TABLE `api_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_users_id`
--
ALTER TABLE `api_users_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`num`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ip_address` (`ip_address`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `ci_session`
--
ALTER TABLE `ci_session`
  ADD PRIMARY KEY (`num`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `name` (`name`),
  ADD KEY `symbol` (`symbol`),
  ADD KEY `approved` (`approved`),
  ADD FULLTEXT KEY `detail` (`detail`);

--
-- Indexes for table `id`
--
ALTER TABLE `id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_id`
--
ALTER TABLE `log_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mail_id`
--
ALTER TABLE `mail_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mujur_account`
--
ALTER TABLE `mujur_account`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `accountid` (`accountid`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `mujur_account160425`
--
ALTER TABLE `mujur_account160425`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `email` (`email`),
  ADD KEY `accountid` (`accountid`);

--
-- Indexes for table `mujur_account160704`
--
ALTER TABLE `mujur_account160704`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `email` (`email`),
  ADD KEY `accountid` (`accountid`);

--
-- Indexes for table `mujur_accountbalance`
--
ALTER TABLE `mujur_accountbalance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`),
  ADD KEY `expired` (`expired`);

--
-- Indexes for table `mujur_accountdetail`
--
ALTER TABLE `mujur_accountdetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`),
  ADD KEY `document` (`document`),
  ADD FULLTEXT KEY `detail` (`detail`);

--
-- Indexes for table `mujur_accountdetail_9`
--
ALTER TABLE `mujur_accountdetail_9`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mujur_accountdocument`
--
ALTER TABLE `mujur_accountdocument`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `mujur_accountrecover`
--
ALTER TABLE `mujur_accountrecover`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mujur_account_8`
--
ALTER TABLE `mujur_account_8`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `accountid` (`accountid`),
  ADD KEY `username` (`username`) USING BTREE;

--
-- Indexes for table `mujur_account_9`
--
ALTER TABLE `mujur_account_9`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `accountid` (`accountid`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `mujur_activation`
--
ALTER TABLE `mujur_activation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`(767),`status`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `mujur_admin`
--
ALTER TABLE `mujur_admin`
  ADD PRIMARY KEY (`adm_id`),
  ADD UNIQUE KEY `adm_username` (`adm_username`),
  ADD KEY `adm_type` (`adm_type`);

--
-- Indexes for table `mujur_api`
--
ALTER TABLE `mujur_api`
  ADD PRIMARY KEY (`id`),
  ADD KEY `error` (`error`),
  ADD FULLTEXT KEY `url` (`url`);
ALTER TABLE `mujur_api`
  ADD FULLTEXT KEY `parameter` (`parameter`);
ALTER TABLE `mujur_api`
  ADD FULLTEXT KEY `response` (`response`);

--
-- Indexes for table `mujur_api160425`
--
ALTER TABLE `mujur_api160425`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mujur_country`
--
ALTER TABLE `mujur_country`
  ADD PRIMARY KEY (`country_id`),
  ADD KEY `country_code` (`country_code`);

--
-- Indexes for table `mujur_country0`
--
ALTER TABLE `mujur_country0`
  ADD PRIMARY KEY (`country_id`),
  ADD KEY `country_kode` (`country_code`,`country_name`);

--
-- Indexes for table `mujur_email`
--
ALTER TABLE `mujur_email`
  ADD PRIMARY KEY (`id`),
  ADD KEY `to` (`to`),
  ADD FULLTEXT KEY `subject` (`subject`);
ALTER TABLE `mujur_email`
  ADD FULLTEXT KEY `messages` (`messages`);

--
-- Indexes for table `mujur_flowlog`
--
ALTER TABLE `mujur_flowlog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `types` (`types`),
  ADD KEY `email` (`email`),
  ADD KEY `accountid` (`accountid`),
  ADD FULLTEXT KEY `param` (`param`);

--
-- Indexes for table `mujur_logs`
--
ALTER TABLE `mujur_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `controller` (`controller`),
  ADD FULLTEXT KEY `function` (`function`);
ALTER TABLE `mujur_logs`
  ADD FULLTEXT KEY `param` (`param`);

--
-- Indexes for table `mujur_password`
--
ALTER TABLE `mujur_password`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `password` (`password`);

--
-- Indexes for table `mujur_price`
--
ALTER TABLE `mujur_price`
  ADD PRIMARY KEY (`id`),
  ADD KEY `types` (`types`),
  ADD KEY `currency` (`currency`),
  ADD KEY `approved` (`approved`),
  ADD FULLTEXT KEY `detail` (`detail`);

--
-- Indexes for table `mujur_register`
--
ALTER TABLE `mujur_register`
  ADD PRIMARY KEY (`reg_id`),
  ADD KEY `reg_username` (`reg_username`),
  ADD KEY `reg_email` (`reg_email`) USING BTREE;

--
-- Indexes for table `mujur_register1702`
--
ALTER TABLE `mujur_register1702`
  ADD PRIMARY KEY (`reg_id`),
  ADD KEY `reg_username` (`reg_username`),
  ADD KEY `reg_email` (`reg_email`);

--
-- Indexes for table `mujur_register1705`
--
ALTER TABLE `mujur_register1705`
  ADD PRIMARY KEY (`reg_id`),
  ADD KEY `reg_username` (`reg_username`),
  ADD KEY `reg_email` (`reg_email`),
  ADD KEY `reg_username_2` (`reg_username`),
  ADD KEY `reg_status` (`reg_status`),
  ADD KEY `reg_agent` (`reg_agent`);

--
-- Indexes for table `mujur_users`
--
ALTER TABLE `mujur_users`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `u_email` (`u_email`),
  ADD KEY `u_type` (`u_type`),
  ADD KEY `u_status` (`u_status`),
  ADD KEY `u_mastercode` (`u_mastercode`);

--
-- Indexes for table `mujur_usersdetail`
--
ALTER TABLE `mujur_usersdetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ud_email` (`ud_email`);

--
-- Indexes for table `mujur_usersdocument`
--
ALTER TABLE `mujur_usersdocument`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`udoc_email`),
  ADD KEY `status` (`udoc_status`),
  ADD KEY `profile_pic` (`profile_pic`),
  ADD KEY `profile_type` (`profile_type`);

--
-- Indexes for table `mujur_usersdocument_1`
--
ALTER TABLE `mujur_usersdocument_1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `udoc_email` (`udoc_email`),
  ADD KEY `udoc_status` (`udoc_status`),
  ADD KEY `modified` (`modified`);

--
-- Indexes for table `mujur_userstype`
--
ALTER TABLE `mujur_userstype`
  ADD PRIMARY KEY (`ut_id`),
  ADD KEY `ut_name` (`ut_name`);

--
-- Indexes for table `mujur_users_erase`
--
ALTER TABLE `mujur_users_erase`
  ADD PRIMARY KEY (`u_id`),
  ADD KEY `u_type` (`u_type`),
  ADD KEY `u_status` (`u_status`);

--
-- Indexes for table `palsu`
--
ALTER TABLE `palsu`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `u_email` (`u_email`),
  ADD KEY `u_type` (`u_type`),
  ADD KEY `u_status` (`u_status`);

--
-- Indexes for table `random_id`
--
ALTER TABLE `random_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recover_id`
--
ALTER TABLE `recover_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rest_account`
--
ALTER TABLE `rest_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rest_api`
--
ALTER TABLE `rest_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rest_datatable`
--
ALTER TABLE `rest_datatable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rest_forex`
--
ALTER TABLE `rest_forex`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rest_temp`
--
ALTER TABLE `rest_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `function` (`function`),
  ADD FULLTEXT KEY `data` (`data`);
ALTER TABLE `rest_temp`
  ADD FULLTEXT KEY `result` (`result`);

--
-- Indexes for table `rest_user`
--
ALTER TABLE `rest_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rest_users`
--
ALTER TABLE `rest_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_ping`
--
ALTER TABLE `site_ping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `url` (`url`(255)),
  ADD FULLTEXT KEY `detail` (`detail`);

--
-- Indexes for table `token_id`
--
ALTER TABLE `token_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_id`
--
ALTER TABLE `users_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zbatch_email`
--
ALTER TABLE `zbatch_email`
  ADD PRIMARY KEY (`id`),
  ADD KEY `to` (`to`),
  ADD FULLTEXT KEY `subject` (`subject`);
ALTER TABLE `zbatch_email`
  ADD FULLTEXT KEY `messages` (`messages`);

--
-- Indexes for table `zlog_1462744928`
--
ALTER TABLE `zlog_1462744928`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463263326`
--
ALTER TABLE `zlog_1463263326`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463349726`
--
ALTER TABLE `zlog_1463349726`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463436127`
--
ALTER TABLE `zlog_1463436127`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463522525`
--
ALTER TABLE `zlog_1463522525`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463608932`
--
ALTER TABLE `zlog_1463608932`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463695328`
--
ALTER TABLE `zlog_1463695328`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463781728`
--
ALTER TABLE `zlog_1463781728`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463868127`
--
ALTER TABLE `zlog_1463868127`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1463954528`
--
ALTER TABLE `zlog_1463954528`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464040930`
--
ALTER TABLE `zlog_1464040930`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464127328`
--
ALTER TABLE `zlog_1464127328`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464213729`
--
ALTER TABLE `zlog_1464213729`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464300128`
--
ALTER TABLE `zlog_1464300128`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464386527`
--
ALTER TABLE `zlog_1464386527`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464472933`
--
ALTER TABLE `zlog_1464472933`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464559327`
--
ALTER TABLE `zlog_1464559327`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464645744`
--
ALTER TABLE `zlog_1464645744`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464732129`
--
ALTER TABLE `zlog_1464732129`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464818530`
--
ALTER TABLE `zlog_1464818530`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464904930`
--
ALTER TABLE `zlog_1464904930`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1464991329`
--
ALTER TABLE `zlog_1464991329`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465077728`
--
ALTER TABLE `zlog_1465077728`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465164131`
--
ALTER TABLE `zlog_1465164131`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465250527`
--
ALTER TABLE `zlog_1465250527`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465336927`
--
ALTER TABLE `zlog_1465336927`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465423329`
--
ALTER TABLE `zlog_1465423329`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465509732`
--
ALTER TABLE `zlog_1465509732`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465596129`
--
ALTER TABLE `zlog_1465596129`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465682530`
--
ALTER TABLE `zlog_1465682530`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465768938`
--
ALTER TABLE `zlog_1465768938`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465855322`
--
ALTER TABLE `zlog_1465855322`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1465941723`
--
ALTER TABLE `zlog_1465941723`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1466373723`
--
ALTER TABLE `zlog_1466373723`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1466460122`
--
ALTER TABLE `zlog_1466460122`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zlog_1466546533`
--
ALTER TABLE `zlog_1466546533`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zrest_account`
--
ALTER TABLE `zrest_account`
  ADD PRIMARY KEY (`id`),
  ADD KEY `function` (`function`),
  ADD FULLTEXT KEY `data` (`data`);
ALTER TABLE `zrest_account`
  ADD FULLTEXT KEY `result` (`result`);

--
-- Indexes for table `zrest_datatable`
--
ALTER TABLE `zrest_datatable`
  ADD PRIMARY KEY (`id`),
  ADD KEY `function` (`function`),
  ADD FULLTEXT KEY `data` (`data`);
ALTER TABLE `zrest_datatable`
  ADD FULLTEXT KEY `result` (`result`);

--
-- Indexes for table `zrest_forex`
--
ALTER TABLE `zrest_forex`
  ADD PRIMARY KEY (`id`),
  ADD KEY `function` (`function`),
  ADD FULLTEXT KEY `data` (`data`);
ALTER TABLE `zrest_forex`
  ADD FULLTEXT KEY `result` (`result`);

--
-- Indexes for table `zrest_users`
--
ALTER TABLE `zrest_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `function` (`function`),
  ADD FULLTEXT KEY `data` (`data`);
ALTER TABLE `zrest_users`
  ADD FULLTEXT KEY `result` (`result`);

--
-- Indexes for table `z_api`
--
ALTER TABLE `z_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_api_2`
--
ALTER TABLE `z_api_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `z_temp_api`
--
ALTER TABLE `z_temp_api`
  ADD PRIMARY KEY (`id`),
  ADD KEY `functions` (`functions`),
  ADD KEY `member_login` (`member_login`);

--
-- Indexes for table `z_temp_local`
--
ALTER TABLE `z_temp_local`
  ADD PRIMARY KEY (`id`),
  ADD KEY `api` (`api`),
  ADD KEY `functions` (`functions`),
  ADD KEY `member_login` (`member_login`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_id`
--
ALTER TABLE `account_id`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `acc_detail2`
--
ALTER TABLE `acc_detail2`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `activation_id`
--
ALTER TABLE `activation_id`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `api_account_id`
--
ALTER TABLE `api_account_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `api_datatable_id`
--
ALTER TABLE `api_datatable_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `api_forex_id`
--
ALTER TABLE `api_forex_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `api_id`
--
ALTER TABLE `api_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `api_users_id`
--
ALTER TABLE `api_users_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cache`
--
ALTER TABLE `cache`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ci_session`
--
ALTER TABLE `ci_session`
  MODIFY `num` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `id`
--
ALTER TABLE `id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log_id`
--
ALTER TABLE `log_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mail_id`
--
ALTER TABLE `mail_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_account`
--
ALTER TABLE `mujur_account`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_account160425`
--
ALTER TABLE `mujur_account160425`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_account160704`
--
ALTER TABLE `mujur_account160704`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_accountbalance`
--
ALTER TABLE `mujur_accountbalance`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_accountdetail`
--
ALTER TABLE `mujur_accountdetail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_accountdetail_9`
--
ALTER TABLE `mujur_accountdetail_9`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_accountdocument`
--
ALTER TABLE `mujur_accountdocument`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_accountrecover`
--
ALTER TABLE `mujur_accountrecover`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_account_8`
--
ALTER TABLE `mujur_account_8`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_account_9`
--
ALTER TABLE `mujur_account_9`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_admin`
--
ALTER TABLE `mujur_admin`
  MODIFY `adm_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_api`
--
ALTER TABLE `mujur_api`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_api160425`
--
ALTER TABLE `mujur_api160425`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_country`
--
ALTER TABLE `mujur_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_country0`
--
ALTER TABLE `mujur_country0`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_email`
--
ALTER TABLE `mujur_email`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_flowlog`
--
ALTER TABLE `mujur_flowlog`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_logs`
--
ALTER TABLE `mujur_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_password`
--
ALTER TABLE `mujur_password`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_price`
--
ALTER TABLE `mujur_price`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_register`
--
ALTER TABLE `mujur_register`
  MODIFY `reg_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_register1702`
--
ALTER TABLE `mujur_register1702`
  MODIFY `reg_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_register1705`
--
ALTER TABLE `mujur_register1705`
  MODIFY `reg_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_users`
--
ALTER TABLE `mujur_users`
  MODIFY `u_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'counter';
--
-- AUTO_INCREMENT for table `mujur_usersdetail`
--
ALTER TABLE `mujur_usersdetail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_usersdocument`
--
ALTER TABLE `mujur_usersdocument`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_usersdocument_1`
--
ALTER TABLE `mujur_usersdocument_1`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_userstype`
--
ALTER TABLE `mujur_userstype`
  MODIFY `ut_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mujur_users_erase`
--
ALTER TABLE `mujur_users_erase`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `palsu`
--
ALTER TABLE `palsu`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `random_id`
--
ALTER TABLE `random_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `recover_id`
--
ALTER TABLE `recover_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rest_account`
--
ALTER TABLE `rest_account`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rest_api`
--
ALTER TABLE `rest_api`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rest_datatable`
--
ALTER TABLE `rest_datatable`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rest_forex`
--
ALTER TABLE `rest_forex`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rest_temp`
--
ALTER TABLE `rest_temp`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rest_user`
--
ALTER TABLE `rest_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rest_users`
--
ALTER TABLE `rest_users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `site_ping`
--
ALTER TABLE `site_ping`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `token_id`
--
ALTER TABLE `token_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users_id`
--
ALTER TABLE `users_id`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zbatch_email`
--
ALTER TABLE `zbatch_email`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1462744928`
--
ALTER TABLE `zlog_1462744928`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463263326`
--
ALTER TABLE `zlog_1463263326`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463349726`
--
ALTER TABLE `zlog_1463349726`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463436127`
--
ALTER TABLE `zlog_1463436127`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463522525`
--
ALTER TABLE `zlog_1463522525`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463608932`
--
ALTER TABLE `zlog_1463608932`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463695328`
--
ALTER TABLE `zlog_1463695328`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463781728`
--
ALTER TABLE `zlog_1463781728`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463868127`
--
ALTER TABLE `zlog_1463868127`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1463954528`
--
ALTER TABLE `zlog_1463954528`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464040930`
--
ALTER TABLE `zlog_1464040930`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464127328`
--
ALTER TABLE `zlog_1464127328`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464213729`
--
ALTER TABLE `zlog_1464213729`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464300128`
--
ALTER TABLE `zlog_1464300128`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464386527`
--
ALTER TABLE `zlog_1464386527`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464472933`
--
ALTER TABLE `zlog_1464472933`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464559327`
--
ALTER TABLE `zlog_1464559327`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464645744`
--
ALTER TABLE `zlog_1464645744`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464732129`
--
ALTER TABLE `zlog_1464732129`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464818530`
--
ALTER TABLE `zlog_1464818530`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464904930`
--
ALTER TABLE `zlog_1464904930`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1464991329`
--
ALTER TABLE `zlog_1464991329`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465077728`
--
ALTER TABLE `zlog_1465077728`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465164131`
--
ALTER TABLE `zlog_1465164131`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465250527`
--
ALTER TABLE `zlog_1465250527`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465336927`
--
ALTER TABLE `zlog_1465336927`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465423329`
--
ALTER TABLE `zlog_1465423329`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465509732`
--
ALTER TABLE `zlog_1465509732`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465596129`
--
ALTER TABLE `zlog_1465596129`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465682530`
--
ALTER TABLE `zlog_1465682530`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465768938`
--
ALTER TABLE `zlog_1465768938`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465855322`
--
ALTER TABLE `zlog_1465855322`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1465941723`
--
ALTER TABLE `zlog_1465941723`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1466373723`
--
ALTER TABLE `zlog_1466373723`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1466460122`
--
ALTER TABLE `zlog_1466460122`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zlog_1466546533`
--
ALTER TABLE `zlog_1466546533`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zrest_account`
--
ALTER TABLE `zrest_account`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zrest_datatable`
--
ALTER TABLE `zrest_datatable`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zrest_forex`
--
ALTER TABLE `zrest_forex`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zrest_users`
--
ALTER TABLE `zrest_users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_api`
--
ALTER TABLE `z_api`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_api_2`
--
ALTER TABLE `z_api_2`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_temp_api`
--
ALTER TABLE `z_temp_api`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `z_temp_local`
--
ALTER TABLE `z_temp_local`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
